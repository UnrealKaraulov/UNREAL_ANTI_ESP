# UNREAL_MINI_ANTIESP

1. Copy sounds to sound directory. 
2. Compile anti_esp.sma.
3. Upload sounds to FastDL
